/*============================================================

    Project Bloom
    File: stars.js

    Purpose
    -------
    Creates and manages the night sky.

    Responsibilities
    ----------------
    ✓ Generate layered stars
    ✓ Hero stars
    ✓ Independent twinkle
    ✓ Future parallax
    ✓ Cinematic sparkle moments

    Philosophy
    ----------
    The sky should never demand attention.

    It exists to hold the story.

=============================================================*/


//============================================================
// Imports
//============================================================

import { CONFIG } from "../config.js";

import {

    createElement,
    append,
    setStyles

} from "../utils/helpers.js";

import {

    random,
    randomInt,
    weightedRandom

} from "../utils/random.js";


//============================================================
// Constants
//============================================================

const STAR_COLOURS = [

    {
        value: CONFIG.SKY_COLORS.warmStar,
        weight: 48
    },

    {
        value: CONFIG.SKY_COLORS.ivory,
        weight: 30
    },

    {
        value: CONFIG.SKY_COLORS.coolStar,
        weight: 15
    },

    {
        value: CONFIG.SKY_COLORS.champagne,
        weight: 7
    }

];

const HERO_STAR_NAMES = [

    "Hope",

    "Promise",

    "Dream",

    "Distance",

    "Home"

];


//============================================================
// Private Variables
//============================================================

const stars = [];

const heroStars = [];

let starsContainer = null;

let skyLayers = {};

//============================================================
// Initialise Stars
//============================================================

/**
 * Entry point.
 *
 * This is the only function that app.js
 * will need to call.
 */

export function initStars() {

    createSkyLayers();

    createStars();

    createHeroStars();

    startHeroSparkles();

}

//============================================================
// Create Sky Layers
//============================================================

/**
 * Creates four independent layers.
 *
 * Why?
 * ----
 * Different layers allow us to:
 *
 * ✓ Add depth
 * ✓ Future parallax
 * ✓ Different sparkle behaviour
 * ✓ Better organisation
 */

function createSkyLayers() {

    // Parent container from index.html
    starsContainer = document.getElementById("stars");

    // Safety check
    if (!starsContainer) {

        console.error("Project Bloom: #stars container not found.");

        return;

    }

    // Remove previous layers (useful for future rebuilds)
    starsContainer.innerHTML = "";

    // Create the layer object
    skyLayers = {

        distant: createElement("div"),

        middle: createElement("div"),

        nearby: createElement("div"),

        hero: createElement("div")

    };

    // Apply common class

    Object.values(skyLayers).forEach(layer => {

        layer.classList.add("stars-layer");

        append(starsContainer, layer);

    });

}

//============================================================
// Create All Stars
//============================================================

function createStars() {

    createLayerStars(

        "distant",

        150,

        1,

        1.4

    );

    createLayerStars(

        "middle",

        75,

        1.6,

        2.5

    );

    createLayerStars(

        "nearby",

        30,

        2.8,

        4

    );

}

//============================================================
// Create Layer Stars
//============================================================

function createLayerStars(

    layerName,

    count,

    minSize,

    maxSize

) {

    for (let i = 0; i < count; i++) {

        const star = createSingleStar(

            layerName,

            minSize,

            maxSize,

            false

        );

        append(

            skyLayers[layerName],

            star.element

        );

        stars.push(star);

    }

}

//============================================================
// Create One Star
//============================================================

function createSingleStar(

    layer,

    minSize,

    maxSize,

    hero = false

) {

    const element = createElement("div");

    element.classList.add("star");

    const size = random(minSize, maxSize);

    const opacity = random(.35, .95);

    const colour = weightedRandom(

        STAR_COLOURS

    );

    setStyles(element, {

        width: `${size}px`,

        height: `${size}px`,

        left: `${random(0,100)}%`,

        top: `${random(0,100)}%`,

        opacity,

        background: colour,

        animationDuration: `${random(4,9)}s`,

        animationDelay: `${random(0,6)}s`

    });

    return {

        element,

        layer,

        size,

        opacity,

        hero

    };

}

//============================================================
// Create Hero Stars
//============================================================

function createHeroStars() {

    HERO_STAR_NAMES.forEach(name => {

        const star = createSingleStar(

            "hero",
            4,
            5,
            true

        );

        star.name = name;

        star.element.classList.add("hero-star");

        append(

            skyLayers.hero,
            star.element

        );

        heroStars.push(star);

        stars.push(star);

    });

}

//============================================================
// Hero Star Sparkles
//============================================================

function startHeroSparkles() {

    sparkleHeroStar();

}

function sparkleHeroStar() {

    const delay = random(

        CONFIG.SPARKLE_MIN_DELAY,

        CONFIG.SPARKLE_MAX_DELAY

    );

    setTimeout(() => {

        if (heroStars.length === 0) {

            sparkleHeroStar();

            return;

        }

        const star = heroStars[

            randomInt(

                0,

                heroStars.length - 1

            )

        ];

        star.element.classList.add("sparkling");

        setTimeout(() => {

            star.element.classList.remove("sparkling");

        }, 700);

        sparkleHeroStar();

    }, delay);

}

//============================================================
// Resize
//============================================================

function handleResize() {

    // Reserved for future parallax
    // and viewport calculations.

}

window.addEventListener(

    "resize",

    handleResize

);

//============================================================
// Public API
//============================================================

export {

    sparkleHeroStar

};